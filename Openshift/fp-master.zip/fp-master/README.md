# Food Panda Startup project
Simple J2EE project with maven script to deploy on openshift