package com.techm.adms.dt.dao;

import java.io.Serializable;

import javax.inject.Named;

import com.techm.adms.dt.entity.Project;

@Named
public class DTProjectDAO extends BaseDAO<Project, Serializable> implements IDTProjectDAO {
	
}
