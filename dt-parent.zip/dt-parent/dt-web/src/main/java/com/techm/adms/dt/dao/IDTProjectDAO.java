package com.techm.adms.dt.dao;

import java.io.Serializable;

import com.techm.adms.dt.entity.Project;


public interface IDTProjectDAO extends IBaseDAO<Project, Serializable>{

}
