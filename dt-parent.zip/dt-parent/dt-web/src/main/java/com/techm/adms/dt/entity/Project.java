package com.techm.adms.dt.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity implementation class for Entity: Project
 *
 */
@Entity
@Table(name="project")
public class Project implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	public Project() {
		super();
	}
	@Id
	@Column(name="ProjectID")
	private int projectId;

	@Column(name="ProjectName")
	private String projectName;
	
	@Column(name="ResearchAgenda")
	private String researchAgenda;
	
	@Column(name="ProjectStatus")
	private int projectStatus;
	
	@Column(name="ProjectStage")
	private int projectStage;
	
	@Column(name="CreatedBy")
	private String createdBy;
	
	@Column(name="CreatedDate")
	private Date createdDate;
	
	public int getProjectId() {
		return this.projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return this.projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	
	public String getResearchAgenda() {
		return researchAgenda;
	}

	public void setResearchAgenda(String researchAgenda) {
		this.researchAgenda = researchAgenda;
	}

	public int getProjectStatus() {
		return projectStatus;
	}

	public void setProjectStatus(int projectStatus) {
		this.projectStatus = projectStatus;
	}

	public int getProjectStage() {
		return projectStage;
	}

	public void setProjectStage(int projectStage) {
		this.projectStage = projectStage;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectName="
				+ projectName + "]";
	}

	
}
