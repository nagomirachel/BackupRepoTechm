package com.techm.adms.dt.service;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.techm.adms.dt.common.exception.DTServiceException;
import com.techm.adms.dt.dao.IDTProjectDAO;
import com.techm.adms.dt.entity.Project;

@Local
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class DTProjectBean implements IDTProjectBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DTProjectBean.class);
	
	@Inject
	IDTProjectDAO dtProjectDAO;
	
	//@PersistenceContext
    //protected EntityManager entityManager;

	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void createProject(Project project) throws DTServiceException{
		LOGGER.info("In Bean Class");
		try{
			LOGGER.info("In Bean Class dtProjectDAO###"+ dtProjectDAO);
			dtProjectDAO.create(project);
		}catch(Exception e){
			throw new DTServiceException(e);
		}
		
	}
	
	public List<Project> getAllDTProjectDetails() throws DTServiceException{
		return dtProjectDAO.readAll();
	}

	/**
	 * 
	 * @param project
	 * @throws DTServiceException
	 */
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void upadateProject(Project updatedProject) throws DTServiceException{
		LOGGER.info("In Project Bean Class upadateProject method");
		try{
			Project existingProject = dtProjectDAO.read(updatedProject.getProjectId());
			
			LOGGER.debug(existingProject.toString()+"   1####  "+existingProject);
			existingProject.setProjectName(updatedProject.getProjectName());
			LOGGER.debug(existingProject.toString()+"   2####  "+existingProject);
			dtProjectDAO.update(existingProject);
		}catch(Exception e){
			throw new DTServiceException(e);
		}
	}

	public Project getProjectDetail(int projectId) throws DTServiceException{
		LOGGER.info("In Project Bean Class upadateProject method");
		Project project = new Project();
		try{
			project = dtProjectDAO.read(projectId);
		}catch(Exception e){
			throw new DTServiceException(e);
		}
		return project;
	}
}
