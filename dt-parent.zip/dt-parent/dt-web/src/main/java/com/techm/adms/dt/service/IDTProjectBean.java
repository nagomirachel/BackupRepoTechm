package com.techm.adms.dt.service;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import com.techm.adms.dt.common.exception.DTServiceException;
import com.techm.adms.dt.entity.Project;



public interface IDTProjectBean {
	public void createProject(Project project) throws DTServiceException;
	public List<Project> getAllDTProjectDetails() throws DTServiceException;
	public void upadateProject(Project project) throws DTServiceException;
	public Project getProjectDetail(int projectId) throws DTServiceException;
}
