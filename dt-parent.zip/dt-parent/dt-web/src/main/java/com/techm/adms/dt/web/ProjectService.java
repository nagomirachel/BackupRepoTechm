package com.techm.adms.dt.web;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.techm.adms.dt.common.exception.DTServiceException;
import com.techm.adms.dt.entity.Project;
import com.techm.adms.dt.service.IDTProjectBean;
import com.techm.adms.dt.web.util.ServiceConstants;
import com.techm.adms.dt.web.util.ServiceMessage;
import com.techm.adms.dt.web.util.ServiceMessageHandler;

@Path("/projectservice")
@RequestScoped
public class ProjectService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProjectService.class);
	
	@SuppressWarnings("cdi-ambiguous-dependency")
	@Inject 
	IDTProjectBean dTProjectBean ;
	
	@GET
	@Path("/createProject/{projectId}/{projectName}")
    @Produces({"application/json"})
	public ServiceMessage<Project> createProject(@PathParam("projectId") int projectId, @PathParam("projectName") String projectName){
		ServiceMessage serviceMessage = null;
		try{
			LOGGER.info("In service class");
			Project project = new Project();
			project.setProjectId(projectId);
			project.setProjectName(projectName);
			dTProjectBean.createProject(project);
			LOGGER.info("In service class");
			System.out.println("family updated successfully::::");
			serviceMessage = ServiceMessageHandler.prepareMessage(ServiceConstants.PROJECT_SAVE_SUCCESS);
		}catch(DTServiceException dtServiceException){
			LOGGER.error(dtServiceException.getMessage());
			serviceMessage = ServiceMessageHandler.prepareMessage(ServiceConstants.PROJECT_SAVE_ERROR, dtServiceException);
		}catch(Exception exception){
			LOGGER.error(exception.getMessage());
			serviceMessage = ServiceMessageHandler.prepareMessage(ServiceConstants.PROJECT_SAVE_ERROR, exception);
		}
		return serviceMessage;
	}
	
	@GET
	@Path("/getAll")
	@Produces({"application/json"})
	public List<Project> getDtProjectDetails(){
		List<Project> projectDtlList = new ArrayList<Project>();
		try{
			projectDtlList = dTProjectBean.getAllDTProjectDetails();
		}catch(DTServiceException dtServiceException){
			LOGGER.error(dtServiceException.getMessage());
		}catch(Exception exception){
			LOGGER.error(exception.getMessage());
		}
		return projectDtlList;
	}
	
	@GET
	@Path("/get/{projectId}")
	@Produces({"application/json"})
	public Project readDtProjectDetails(@PathParam("projectId") int projectId){
		Project project = new Project();
		try{
			project = dTProjectBean.getProjectDetail(projectId);
		}catch(DTServiceException dtServiceException){
			LOGGER.error(dtServiceException.getMessage());
		}catch(Exception exception){
			LOGGER.error(exception.getMessage());
		}
		return project;
	}
	
	@GET
	@Path("/updateProject/{projectId}/{projectName}")
    @Produces({"application/json"})
	//@Consumes({"application/json"})
	public void updateProject(@PathParam("projectId") int projectId, @PathParam("projectName") String projectName){
		ServiceMessage serviceMessage = null;
		try{
			
			LOGGER.info("Start in service class");
			Project project = new Project();
			project.setProjectId(projectId);
			project.setProjectName(projectName);
			dTProjectBean.upadateProject(project);
			LOGGER.info("End in service class");
			serviceMessage = ServiceMessageHandler.prepareMessage(ServiceConstants.PROJECT_SAVE_SUCCESS);
		}catch(DTServiceException dtServiceException){
			LOGGER.error(dtServiceException.getMessage());
			serviceMessage = ServiceMessageHandler.prepareMessage(ServiceConstants.PROJECT_SAVE_ERROR, dtServiceException);
		}catch(Exception exception){
			LOGGER.error(exception.getMessage());
			serviceMessage = ServiceMessageHandler.prepareMessage(ServiceConstants.PROJECT_SAVE_ERROR, exception);
		}
	}
}
