module.controller('homeController', function($scope, $state){
    $scope.goToProjects = function(){
        $state.go('home.projects');
    }
})