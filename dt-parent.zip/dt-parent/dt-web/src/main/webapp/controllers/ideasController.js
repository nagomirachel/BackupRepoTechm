module.controller('ideasController', function($scope, $location){

$scope.items = [{
	        id: 'id-1',
	        name: 'Mr'},
	    {
	        id: 'id-2',
	        name: 'Mrs'},
	    {
	        id: 'id-3',
        	name: 'Ms'}];
    
$scope.goToIdeaFeedback = function(){
    $location.path('/ideaFeedback');
}
    
});