module.controller('menuController', function($scope, $state){
    $scope.isActive = function(viewLocation){
        return $state.is(viewLocation);
    }
})