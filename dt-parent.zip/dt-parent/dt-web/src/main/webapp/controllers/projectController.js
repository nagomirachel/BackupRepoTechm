module.controller('projectController', function($scope, projectService){
    $scope.getProjects = function(){
        projectService.getdata(function(data){
            alert(data);
            $scope.projects = data;                  
        })
    }
})