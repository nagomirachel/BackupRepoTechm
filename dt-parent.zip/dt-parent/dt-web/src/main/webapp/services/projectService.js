module.service('projectService', function($http){
    this.getdata = function(callbackProject){
        {
						var responsePromise = $http.get("http://localhost:8080/dt-web/webresources/projectservice/getAll");
						responsePromise.success(function(data, status, headers, config) {
						callbackProject(data);
				        });
					    responsePromise.error(function(data, status, headers, config) {
				        alert("AJAX failed! because no webservice is attached yet");      					 
					    });
	   };
    }
});